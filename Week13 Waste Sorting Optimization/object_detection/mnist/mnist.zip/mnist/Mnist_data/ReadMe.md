The Mnist datasets.

You can download the datasets on the website: http://yann.lecun.com/exdb/mnist/ or

download them from my URL: http://pan.baidu.com/s/1mh0ICBI ( password: dlut ).

Four files are available: 

 - train-images-idx3-ubyte.gz : training set images (9912422 bytes) 
 - train-labels-idx1-ubyte.gz : training set labels (28881 bytes) 
 - t10k-images-idx3-ubyte.gz  : test set images (1648877 bytes) 
 - t10k-labels-idx1-ubyte.gz  : test set labels (4542 bytes)
 
After the files are acquired, you can just copy them to the folder "Mnist_data".
